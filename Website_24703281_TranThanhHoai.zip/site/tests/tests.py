import os,re,json,time,glob,subprocess,urllib.request,concurrent.futures as cf
from html.parser import HTMLParser
S="/home/claude/site"; R={}
def lum(h):
    h=h.lstrip("#"); c=[int(h[i:i+2],16)/255 for i in (0,2,4)]
    c=[x/12.92 if x<=.03928 else ((x+.055)/1.055)**2.4 for x in c]; return .2126*c[0]+.7152*c[1]+.0722*c[2]
def cr(a,b): x,y=sorted([lum(a),lum(b)],reverse=True); return round((x+.05)/(y+.05),2)
pairs=[("Chữ chính","#1a1f36","#ffffff"),("Chữ phụ/figcaption","#4a5170","#ffffff"),("Liên kết","#0b4f9c","#ffffff"),("Nút (chữ trắng/nền xanh)","#ffffff","#0b4f9c"),("Menu (trắng/navy)","#ffffff","#12204a"),("Menu hiện tại (navy/trắng)","#12204a","#ffffff"),("Menu hover","#ffffff","#27407f"),("Liên kết chân trang","#ffd98a","#12204a"),("Thông báo lỗi","#8a1c1c","#ffffff"),("Nút phát (navy/trắng)","#12204a","#ffffff")]
R["contrast"]=[(n,f,b,cr(f,b)) for n,f,b in pairs]
class P(HTMLParser):
    def __init__(s): super().__init__(); s.refs=[]; s.st=[]; s.err=[]; s.imgs=0; s.noalt=0; s.nosize=0; s.cur=0; s.ids=[]; s.inline=0
    def handle_starttag(s,t,a):
        a=dict(a)
        if t not in("meta","link","img","br","source","track","input","hr"): s.st.append(t)
        for k in("href","src"):
            if k in a: s.refs.append(a[k])
        for u in re.findall(r"(\S+)\s+\d+w",a.get("srcset","")): s.refs.append(u)
        if t=="img":
            s.imgs+=1; s.noalt+= "alt" not in a; s.nosize+= not("width" in a and "height" in a)
        if a.get("aria-current")=="page" and t=="a": s.cur+=1
        if "id" in a: s.ids.append(a["id"])
        if "style" in a: s.inline+=1
    def handle_endtag(s,t):
        if t in s.st:
            while s.st and s.st[-1]!=t: s.err.append("không đóng <"+s.st.pop()+">")
            s.st.pop()
        else: s.err.append("thừa </"+t+">")
pages=sorted(glob.glob(S+"/*.html")); R["pages"]={}
for p in pages:
    t=open(p,encoding="utf-8").read(); q=P(); q.feed(t)
    broken=[r for r in q.refs if not r.startswith(("http","#","mailto")) and not os.path.exists(os.path.join(S,r.split("#")[0]))]
    R["pages"][os.path.basename(p)]=dict(links=len(q.refs),broken=broken,tag_err=q.err+["thẻ mở chưa đóng: "+",".join(q.st)]*bool(q.st),imgs=q.imgs,noalt=q.noalt,nosize=q.nosize,current=q.cur,dup_id=len(q.ids)-len(set(q.ids)),inline_style=q.inline,doctype=t.startswith("<!DOCTYPE html>"),lang='lang="vi"' in t,utf8='charset="utf-8"' in t,h1=t.count("<h1"),main=("<main" in t),size=len(t.encode()))
# vtt utf8
v=open(S+"/video/phu-de-vi.vtt","rb").read(); v.decode("utf-8"); R["vtt_ok"]=v.startswith(b"WEBVTT")
R["js_lines"]={os.path.basename(f):len(open(f).read().splitlines()) for f in glob.glob(S+"/js/*.js")}
# HTTP 200 for all files
files=[os.path.relpath(f,S) for f in glob.glob(S+"/**/*",recursive=True) if os.path.isfile(f) and ".git" not in f]
bad=[f for f in files if urllib.request.urlopen("http://127.0.0.1:8002/"+f).status!=200]; R["http_all_200"]=(len(files),bad)
sz=lambda f:os.path.getsize(S+"/"+f)
# ngân sách trang chủ (trường hợp xấu nhất: màn hình lớn tải ảnh jpg 1280 + 5 thumb 640)
home=dict(html=sz("index.html"),css=sz("css/site.css"),hero=sz("img/hero-1280.jpg"),thumbs=sum(sz(f"img/{k}-640.jpg") for k in("am-thuc","kien-truc","song-nuoc","le-hoi","am-thanh")))
home["total"]=sum(home.values()); R["budget_worst"]=home
mob=dict(html=sz("index.html"),css=sz("css/site.css"),hero=sz("img/hero-480.webp"),thumbs=sum(sz(f"img/{k}-320.jpg") for k in("am-thuc","kien-truc","song-nuoc","le-hoi","am-thanh")))
mob["total"]=sum(mob.values()); R["budget_mobile"]=mob
R["requests_home_mobile"]=1+1+1+5
# tối ưu: đo thật
from PIL import Image
im=Image.open("hero-original.png").convert("RGB"); im.save("base-hero.jpg",quality=95); b1=os.path.getsize("base-hero.jpg"); a1=sz("img/hero-480.webp")
R["opt1_img"]=(b1,a1,round(100*(1-a1/b1),1))
b2=b1+sum(sz(f"img/{k}-640.jpg") for k in("am-thuc","kien-truc","song-nuoc","le-hoi","am-thanh")); a2=b1  # lazy: chỉ hero
tot_eager=a1+mob["thumbs"]; R["opt2_lazy"]=(tot_eager,a1,round(100*(1-a1/tot_eager),1))
subprocess.run("ffmpeg -y -loglevel error -f concat -safe 0 -i /dev/null x 2>/dev/null",shell=True)
subprocess.run("ffmpeg -y -loglevel error -i /home/claude/site/video/intro.mp4 -vf scale=1280:720 -c:v libx264 -crf 23 -c:a aac -b:a 128k base-video.mp4",shell=True)
bv=os.path.getsize("base-video.mp4"); av=sz("video/intro.mp4"); R["opt3_video"]=(bv,av,round(100*(1-av/bv),1))
subprocess.run("ffmpeg -y -loglevel error -i /home/claude/site/audio/ambient.mp3 -b:a 192k base-audio.mp3",shell=True)
ba=os.path.getsize("base-audio.mp3"); aa=sz("audio/ambient.mp3"); R["opt4_audio"]=(ba,aa,round(100*(1-aa/ba),1))
R["bitrate_kbps"]={f:round(sz(f)*8/18/1000) for f in("video/intro.mp4","video/intro.webm")}
R["bw300_mbps"]={"2.5Mbps":300*2.5,"mp4_thuc":round(300*R["bitrate_kbps"]["video/intro.mp4"]/1000,1),"webm_thuc":round(300*R["bitrate_kbps"]["video/intro.webm"]/1000,1)}
# stress: 100 yêu cầu đồng thời
def hit(_):
    t=time.time(); r=urllib.request.urlopen("http://127.0.0.1:8002/index.html"); r.read(); return r.status,time.time()-t
t0=time.time()
with cf.ThreadPoolExecutor(100) as ex: res=list(ex.map(hit,range(100)))
dt=time.time()-t0; ts=sorted(x[1] for x in res)
R["stress"]=dict(n=100,conc=100,ok=sum(1 for s,_ in res if s==200),total_s=round(dt,2),rps=round(100/dt,1),p50_ms=round(ts[49]*1000),p95_ms=round(ts[94]*1000),max_ms=round(ts[-1]*1000))
json.dump(R,open("results.json","w"),ensure_ascii=False,indent=1); print(json.dumps(R,ensure_ascii=False,indent=1))
