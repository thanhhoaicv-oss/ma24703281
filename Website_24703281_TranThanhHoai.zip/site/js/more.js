// «Xem thêm»: nạp media.json bằng fetch, đo dung lượng đã tải
(function () {
  var b = document.getElementById("moreBtn"), ul = document.getElementById("gallery"), st = document.getElementById("moreStat");
  if (!b) return;
  b.addEventListener("click", function () {
    b.disabled = true; b.textContent = "Đang tải…";
    fetch("media/media.json").then(function (r) {
      if (!r.ok) throw new Error(r.status);
      return r.text();
    }).then(function (t) {
      JSON.parse(t).forEach(function (m) {
        var li = document.createElement("li"); li.className = "card";
        li.innerHTML = '<figure><img src="' + m.src + '" alt="' + m.alt + '" width="640" height="360" loading="lazy"><figcaption>' + m.title + '</figcaption></figure>';
        ul.appendChild(li);
      });
      st.textContent = "Đã nạp thêm bằng fetch: " + t.length + " byte JSON (không tải lại cả trang).";
      b.hidden = true;
    }).catch(function (e) { b.disabled = false; b.textContent = "Thử lại"; st.textContent = "Lỗi nạp danh sách: " + e.message; });
  });
})();
