// Trình phát tùy biến – Trần Thanh Hoài (24703281)
(function () {
  var v = document.getElementById("video"), bar = document.getElementById("bar");
  var btn = document.getElementById("playBtn"), msg = document.getElementById("msg");
  var tm = document.getElementById("time");
  if (!v || !btn) return;
  v.removeAttribute("controls");              // có JS thì dùng điều khiển tùy biến
  document.getElementById("ctrl").hidden = false;
  function fmt(s) { s = Math.floor(s || 0); return Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0"); }
  function say(t) { msg.textContent = t; }
  function toggle() {
    if (v.paused) {
      var p = v.play();
      if (p && p.catch) p.catch(function (e) { say("Không thể phát video: " + e.name + ". Hãy bấm lại hoặc đổi trình duyệt."); });
    } else { v.pause(); }
  }
  btn.addEventListener("click", toggle);
  v.addEventListener("click", toggle);
  v.addEventListener("play", function () { btn.textContent = "⏸ Tạm dừng"; btn.setAttribute("aria-pressed", "true"); say(""); });
  v.addEventListener("pause", function () { btn.textContent = "▶ Phát"; btn.setAttribute("aria-pressed", "false"); });
  v.addEventListener("timeupdate", function () {
    bar.value = v.duration ? v.currentTime / v.duration : 0;
    tm.textContent = fmt(v.currentTime) + " / " + fmt(v.duration);
  });
  v.addEventListener("loadedmetadata", function () { tm.textContent = "0:00 / " + fmt(v.duration); });
  v.addEventListener("ended", function () { v.currentTime = 0; });
  v.addEventListener("error", function () { say("Lỗi tải video (mã " + (v.error ? v.error.code : "?") + "). Vui lòng tải lại trang."); });
  bar.addEventListener("click", function (e) {  // bấm vào thanh để tua
    var r = bar.getBoundingClientRect();
    if (v.duration) v.currentTime = ((e.clientX - r.left) / r.width) * v.duration;
  });
})();
