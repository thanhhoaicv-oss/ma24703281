# Thư mục media – Sài Gòn – Chợ Lớn: Góc Nhìn Đa Phương Tiện
Tác giả: Trần Thanh Hoài – MSSV 24703281

| Tệp | Mô tả | Nguồn / giấy phép |
|---|---|---|
| img/*.jpg, *.webp | Tranh minh họa vẽ bằng mã Python (Pillow) | Tự tạo, CC0 |
| video/intro.mp4, intro.webm | Video giới thiệu 18 s, 640×360 | Tự tạo bằng FFmpeg từ ảnh tự vẽ, CC0 |
| video/phu-de-vi.vtt | Phụ đề tiếng Việt (UTF-8) | Tự viết |
| audio/ambient.mp3, ambient.ogg | Âm nền (hợp âm sin) 20 s | Tự tạo bằng FFmpeg, CC0 |
| media/media.json | Danh sách «xem thêm» | Tự viết |

Không dùng Flash, ActiveX, WML, VRML.
